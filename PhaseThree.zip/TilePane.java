import javafx.scene.layout.HBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.geometry.Pos;
import javafx.scene.shape.Circle;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.paint.Paint; 
import javafx.scene.text.Text;
public class TilePane extends HBox
{
   private Tile tile;
   private String letter;
   private boolean clicked;
   
   public TilePane(Tile tile)
   { 
      super();
      this.tile = tile;
      letter = tile.showLetter();
      this.setPrefSize(45,45);
      this.setAlignment(Pos.CENTER);
      defaultTile();
      clicked = false;
      Text t = new Text(letter);
      Font letterFont = new Font("Monotype Corsiva", 30);
      t.setFont(letterFont);
      t.setStyle("-fx-font-weight: bold");
      t.setFill(Color.WHITE);
      this.getChildren().add(t);
      
   }
   
   public void setSelected()
   {
      this.setStyle("-fx-border-width: 2;"
                 +"-fx-border-color: Maroon;" + 
                 "-fx-background-color:IndianRed;" +
                 "-fx-border-radius: 5;");      
      clicked = true;
   }
   
   public void setUnselected()
   {
      defaultTile();
      clicked = false;
   }
   
   public void defaultTile()
   {
      this.setStyle("-fx-border-width: 2;"
                 +"-fx-border-color: Maroon;" + 
                 "-fx-background-color:FireBrick;" +
                 "-fx-border-radius: 5;");
   }
   
   public String getLetter()
   {
      return letter;
   }
   
   public boolean getClicked()
   {
      return clicked;
   }
   
   public Tile getTile()
   {
      return tile; 
   }

   
   
}

